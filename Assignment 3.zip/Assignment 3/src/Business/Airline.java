 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author ajaygoel
 */
public class Airline {
    
    private String Airline_name;
    private FlightDirectory flightDirectory;
    
    public Airline(){
        flightDirectory = new FlightDirectory();
    }
    
    public String getAirline_name() {
        return Airline_name;
    }

    public void setAirline_name(String Airline_name) {
        this.Airline_name = Airline_name;
    }
    
    public FlightDirectory getFlightDirectory() {
        return flightDirectory;
    }
    
    @Override
    public String toString(){
        return Airline_name;
    }

}
