/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author ajaygoel
 */
public class Customer {
    
    private String Customer_name;
    private String Customer_email;
    private int Customer_mobile;
    private int customer_age;
    private String gender;
    

    public String getCustomer_name() {
        return Customer_name;
    }

    public void setCustomer_name(String Customer_name) {
        this.Customer_name = Customer_name;
    }

    public String getCustomer_email() {
        return Customer_email;
    }

    public void setCustomer_email(String Customer_email) {
        this.Customer_email = Customer_email;
    }

    public int getCustomer_mobile() {
        return Customer_mobile;
    }

    public void setCustomer_mobile(int Customer_mobile) {
        this.Customer_mobile = Customer_mobile;
    }

    public int getCustomer_age() {
        return customer_age;
    }

    public void setCustomer_age(int customer_age) {
        this.customer_age = customer_age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    @Override
    public String toString(){
        return Customer_name;
}
    
}
