/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.Date;

/**
 *
 * @author ajaygoel
 */
public class Flight {
    
    private String Flight_name;
    private static int count;
    private int flight_id;
    private String Source;
    private String Destination;
    private String Departure_Date;
    private String Flight_class;
    private int Flight_charges;
    private String Time_hrs;
    private String Airliner_name;
    private int Seats = 500;
    private CustomerDirectory customerDirectory;
    
    public Flight(){
        count++;
        flight_id = count;
        customerDirectory = new CustomerDirectory();
        
    }

    public int getSeats() {
        return Seats;
    }

    public void setSeats(int Seats) {
        this.Seats = Seats;
    }

   
    
    
    public String getFlight_name() {
        return Flight_name;
    }

    public void setFlight_name(String Flight_name) {
        this.Flight_name = Flight_name;
    }

    public int getflight_id() {
        return flight_id;
    }


    public String getSource() {
        return Source;
    }

    public void setSource(String Source) {
        this.Source = Source;
    }

    public String getDestination() {
        return Destination;
    }

    public void setDestination(String Destination) {
        this.Destination = Destination;
    }

 

    public String getFlight_class() {
        return Flight_class;
    }

    public void setFlight_class(String Flight_class) {
        this.Flight_class = Flight_class;
    }

    public int getFlight_charges() {
        return Flight_charges;
    }

    public void setFlight_charges(int Flight_charges) {
        this.Flight_charges = Flight_charges;
    }

    public String getTime_hrs() {
        return Time_hrs;
    }

    public void setTime_hrs(String Time_hrs) {
        this.Time_hrs = Time_hrs;
    }

    public String getAirliner_name() {
        return Airliner_name;
    }

    public void setAirliner_name(String Airliner_name) {
        this.Airliner_name = Airliner_name;
    }

    public String getDeparture_Date() {
        return Departure_Date;
    }

    public void setDeparture_Date(String Departure_Date) {
        this.Departure_Date = Departure_Date;
    }

    public CustomerDirectory getCustomerDirectory() {
        return customerDirectory;
    }
    
    

    @Override
    public String toString(){
        return Flight_name;
    }
    
    
}
