/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author ajaygoel
 */
public class FlightDirectory {
    
    private ArrayList<Flight> FlightDirectory;
    
    public FlightDirectory() 
    {
        FlightDirectory = new ArrayList<Flight>();
    }
    
    public ArrayList<Flight> getFlightDirectory() {
        return FlightDirectory;
    }

    public Flight addflight()
    {
        Flight fl = new Flight();
        FlightDirectory.add(fl);
        return fl;
        
    }
    
    public void removeflight(Flight fl)
    {
        FlightDirectory.remove(fl);
        
    }
    
    public ArrayList<Flight> getFlight(String Source, String Destination){
        ArrayList<Flight> flights = new ArrayList<>();
        for(Flight flight : FlightDirectory)
            if((flight.getSource().equalsIgnoreCase(Source))&&(flight.getDestination().equalsIgnoreCase(Destination)))
                flights.add(flight);
        return flights;
        
    }

    public  ArrayList<Flight> getBestFlight(String Source, String Destination)
    {
        ArrayList<Flight> flights = new ArrayList<>();
        int length = 0;
        ArrayList<Integer> minCost = new ArrayList<Integer>();
        for(Flight flight : FlightDirectory)
            length++;
        
        for(Flight flight : FlightDirectory)
            if((flight.getSource().equalsIgnoreCase(Source))&&(flight.getDestination().equalsIgnoreCase(Destination)))
            {    
                minCost.add(flight.getFlight_charges());
                //int min = flight.getFlight_charges();
                //for(int i =0;i<length ;i++)
                //{   
                    //if(min>FlightDirectory.get(i).getFlight_charges())
                        //min = i;
                //}
            }
        int min = minCost.get(0);
        for(int i=1; i<minCost.size(); i++)
        {
            if(min>minCost.get(i))
            {
                min = minCost.get(i);
            }
        }
            System.out.println(min);
        
        for(Flight flight : FlightDirectory)
            if((flight.getSource().equalsIgnoreCase(Source))&&(flight.getDestination().equalsIgnoreCase(Destination))&&(flight.getFlight_charges()==min))
            {
                flights.add(flight);
                System.out.println(min);
            }
        return flights;
            }
    
    public  ArrayList<Flight> getBestFlightTime(String Source, String Destination)
    {
        ArrayList<Flight> flights = new ArrayList<>();
        int length = 0;
        ArrayList<Integer> mintime = new ArrayList<Integer>();
        for(Flight flight : FlightDirectory)
            length++;
        
        for(Flight flight : FlightDirectory)
            if((flight.getSource().equalsIgnoreCase(Source))&&(flight.getDestination().equalsIgnoreCase(Destination)))
            {    
                mintime.add(Integer.parseInt(flight.getTime_hrs()));
                
            }
        int min = mintime.get(0);
        for(int i=1; i<mintime.size(); i++)
        {
            if(min>mintime.get(i))
            {
                min = mintime.get(i);
            }
        }
            System.out.println(min);
        
        for(Flight flight : FlightDirectory)
            if((flight.getSource().equalsIgnoreCase(Source))&&(flight.getDestination().equalsIgnoreCase(Destination))&&(Integer.parseInt(flight.getTime_hrs())==min))
            {
                flights.add(flight);
                System.out.println(min);
            }
        return flights;
            }
        
        
    }
   
