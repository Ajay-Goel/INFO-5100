/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import Business.Product.Product;
import java.util.Date;

/**
 *
 * @author ajaygoel
 */
public class OrderItem {
    
    private int quantity;
    private double salesPrice;
    private Product product;
    private String orderStatus;
    private String Invoice_Status;
    private double salesTax;
    private double delivery_charge;
    private Date orderDate;

    public Date getOrderDate() {
        return orderDate;
    }

    public OrderItem() {
        orderStatus="IN PROCESS";
       // DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        orderDate= date;
        
        System.out.println("order Item date= "+ orderDate);
    }    

    public String getInvoice_Status() {
        return Invoice_Status;
    }

    public void setInvoice_Status(String Invoice_Status) {
        this.Invoice_Status = Invoice_Status;
    }

    
    
    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
    

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quality) {
        this.quantity = quality;
    }

    public double getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice() {
        //this.salesPrice = salesPrice;
        salesPrice= quantity*product.getPrice();
    }

    
    public double getSalesTax() {
        return salesTax;
    }

    public void setSalesTax() {
        salesTax = salesPrice*0.05;
    }
    
    
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public double getDelivery_charge() {
        return delivery_charge;
    }

    public void setDelivery_charge() {
        if(salesPrice>75)
        {
            delivery_charge = 0;
        }
        else
        {
            delivery_charge = salesPrice*0.05;
        }
        
    }
    
    
    
    @Override
    public String toString(){
        return product.getProdName();
    }
    
}
