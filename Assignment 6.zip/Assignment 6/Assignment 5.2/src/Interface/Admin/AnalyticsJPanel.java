/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface.Admin;

import Business.Business;
import Business.Customer.Customer;
import Business.Order.OrderItem;
import Business.Product.Product;
import Business.Supplier.Supplier;
import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author ankit
 */
public class AnalyticsJPanel extends javax.swing.JPanel {

    /**
     * Creates new form AnalyticsJPanel
     */
    public AnalyticsJPanel() {

    }
    private JPanel userProcessContainer;
    private Business business;

    public AnalyticsJPanel(JPanel userProcessContainer, Business business) {
        initComponents();

        this.business = business;
        this.userProcessContainer = userProcessContainer;

        revenueBetTxtField.setEditable(false);
        totalAdminRevenueJTxtField.setEditable(false);

        populateTableProduct();
        populateTableSupplier();
        populateTableCustomer();
        populateFields();
        populateComboBox();
    }

    public void populateTableProduct() {

        //   System.out.println("in loop populateTableProduct " );
        int rowCount = prodJTbl.getRowCount();

        DefaultTableModel model = (DefaultTableModel) prodJTbl.getModel();

        for (int i = rowCount - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(prodJTbl.getModel());
        prodJTbl.setRowSorter(sorter);
 
        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        sortKeys.add(new RowSorter.SortKey(4, SortOrder.DESCENDING));
        sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));

        sorter.setSortKeys(sortKeys);
        int noOfProd = 0;
        double salesPrice = 0;

        for (Product p : business.getProductDirectory().getProductDirectory()) {
            for (Customer cust : business.getCustomerDirectory().getCustomerDirectory()) {
                for (OrderItem oi : cust.getOrderList()) {
                    if (oi.getProduct().equals(p)) {

                        if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {

                            noOfProd = noOfProd + oi.getQuantity();
                            salesPrice = salesPrice + oi.getSalesPrice();
                        }
                    }
                }
            }
            Object Row[] = new Object[5];
            Row[0] = p.getProdName();
            Row[1] = p.getCategories();
            Row[2] = business.getSupplierName(p);
            Row[3] = noOfProd;
            Row[4] = salesPrice;

            model.addRow(Row);

            noOfProd = 0;
            salesPrice = 0;

        }

    }

    public void populateTableSupplier() {

        int rowCount = suppDataJTbl.getRowCount();

        DefaultTableModel model = (DefaultTableModel) suppDataJTbl.getModel();

        for (int i = rowCount - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(suppDataJTbl.getModel());
        suppDataJTbl.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        sortKeys.add(new RowSorter.SortKey(2, SortOrder.DESCENDING));
        sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));

        sorter.setSortKeys(sortKeys);

        int totalProdSold = 0;
        double totalSales = 0;

        for (Supplier s : business.getSupplierDirectory().getSupplierDirectory()) {
            for (OrderItem oi : s.getSuppOrderList().keySet()) {
                if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {
                    totalProdSold = totalProdSold + oi.getQuantity();
                    totalSales = totalSales + oi.getSalesPrice();
                }
            }

            Object Row[] = new Object[4];
            Row[0] = s.getSupplier_name();
            Row[1] = s.getSupplier_location();
            Row[2] = totalSales;
            Row[3] = totalProdSold;

            model.addRow(Row);

            totalProdSold = 0;
            totalSales = 0;
        }

    }

    public void populateTableCustomer() {

        int rowCount = custDataJTbl.getRowCount();

        DefaultTableModel model = (DefaultTableModel) custDataJTbl.getModel();

        for (int i = rowCount - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        int noItem = 0;
        double totalPurchase = 0;

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(custDataJTbl.getModel());
        custDataJTbl.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        sortKeys.add(new RowSorter.SortKey(2, SortOrder.DESCENDING));
        sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));

        sorter.setSortKeys(sortKeys);

        for (Customer c : business.getCustomerDirectory().getCustomerDirectory()) {
            for (OrderItem oi : c.getOrderList()) {
                if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {
                    noItem = oi.getQuantity() + noItem;
                    totalPurchase = totalPurchase + oi.getSalesPrice();
                }
            }

            Object Row[] = new Object[4];
            Row[0] = c.getFirstName() + " " + c.getLastName();
            Row[1] = c.getLocation();
            Row[2] = totalPurchase;
            Row[3] = noItem;

            model.addRow(Row);

            noItem = 0;
            totalPurchase = 0;
        }

    }

    public void populateFields() {

        double total_admin_revenue = 0;

        for (Customer customer : business.getCustomerDirectory().getCustomerDirectory()) {

            for (OrderItem oi : customer.getOrderList()) {

                if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {

                    double admin_revenue = 0.1 * oi.getSalesPrice();

                    total_admin_revenue = admin_revenue + total_admin_revenue;
                }
            }
        }

        totalAdminRevenueJTxtField.setText(String.valueOf(total_admin_revenue));

        revenueBetTxtField.setText("");

    }

    public void populateComboBox() {
        categoryJComboBox.removeAllItems();
        categoryJComboBox.addItem("All");
        categoryJComboBox.addItem("Electronics");
        categoryJComboBox.addItem("Footwear");
        categoryJComboBox.addItem("Topwear");
        categoryJComboBox.addItem("Bottomwear");
        categoryJComboBox.addItem("Accessories");
        categoryJComboBox.addItem("Home&Furniture");

        suppJComboBox.removeAllItems();
        suppJComboBox.addItem("All");

        for (Supplier s : business.getSupplierDirectory().getSupplierDirectory()) {
            suppJComboBox.addItem(s.getSupplier_name());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        prodJTbl = new javax.swing.JTable();
        suppJComboBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        categoryJComboBox = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        suppDataJTbl = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        custDataJTbl = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        totalAdminRevenueJTxtField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        getRevenueJBtn = new javax.swing.JButton();
        revenueBetTxtField = new javax.swing.JTextField();
        backJBtn = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Sales Report Analysis");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Product Performance");

        prodJTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Name", "Category", "Supplier Name", "Quantity Sold", "Sales Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(prodJTbl);

        suppJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                suppJComboBoxActionPerformed(evt);
            }
        });

        jLabel3.setText("Filter By: ");

        jLabel4.setText("Supplier");

        jLabel5.setText("Category");

        categoryJComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoryJComboBoxActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Supplier Revenue Data");

        suppDataJTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Supplier Name", "Location", "Total Revenue", "Total Product Sold"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(suppDataJTbl);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Customer Data");

        custDataJTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer Name", "Location", "Total Purchase", "Number of Item"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(custDataJTbl);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Revenue Report");

        jLabel9.setText("Total Revenue:");

        jLabel10.setText("Revenue between: ");

        jLabel11.setText("From");

        jLabel12.setText("To");

        getRevenueJBtn.setText("Get");
        getRevenueJBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                getRevenueJBtnActionPerformed(evt);
            }
        });

        backJBtn.setText("Back");
        backJBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backJBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addGap(18, 18, 18)
                                    .addComponent(categoryJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(suppJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addComponent(jLabel6)
                        .addComponent(jLabel7)
                        .addComponent(jLabel8)
                        .addComponent(backJBtn)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 577, Short.MAX_VALUE)
                        .addComponent(jScrollPane2)
                        .addComponent(jScrollPane1)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(38, 38, 38)
                            .addComponent(revenueBetTxtField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(36, 36, 36)
                            .addComponent(totalAdminRevenueJTxtField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(156, 156, 156)
                        .addComponent(jLabel12)
                        .addGap(156, 156, 156)
                        .addComponent(getRevenueJBtn)))
                .addContainerGap(140, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(suppJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(categoryJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(totalAdminRevenueJTxtField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(revenueBetTxtField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel12))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel11)
                        .addComponent(getRevenueJBtn)))
                .addGap(34, 34, 34)
                .addComponent(backJBtn)
                .addContainerGap(136, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void getRevenueJBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_getRevenueJBtnActionPerformed
        // TODO add your handling code here:

        Date from = null;
        Date to = null;
        try {
          from = fromDateChooser.getDate();
            to = toDateChooser.getDate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select valid dates from calender", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (from == null || to == null) {
            JOptionPane.showMessageDialog(null, "None of the fields can be empty", "Warning", JOptionPane.WARNING_MESSAGE);
            return;

        }

        if (from.compareTo(to) > 0) {
            JOptionPane.showMessageDialog(null, "From date should not be greater than To date", "Warning", JOptionPane.WARNING_MESSAGE);
            return;

        }

        //    System.out.println("1 from- "+from+" to- "+to);
//        Date date=new Date();
//        
//       
//
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(to);
//        calendar.add(Calendar.DAY_OF_YEAR, +1);
//
//        to = calendar.getTime();
//
//        Calendar calendarF = Calendar.getInstance();
//        calendarF.setTime(from);
//        calendarF.add(Calendar.DAY_OF_YEAR, -1);
//        from = calendarF.getTime();
        double adminRevenueBet = 0;

        for (Customer cust : business.getCustomerDirectory().getCustomerDirectory()) {
            for (OrderItem oi : cust.getOrderList()) {
                if (oi.getOrderDate().compareTo(from) > 0 && oi.getOrderDate().compareTo(to) < 0) {
                    if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {
                        double admin_revenue = 0.1 * oi.getSalesPrice();

                        adminRevenueBet = admin_revenue + adminRevenueBet;
                    }
                }

            }
        }

        revenueBetTxtField.setText(String.valueOf(adminRevenueBet));


    }//GEN-LAST:event_getRevenueJBtnActionPerformed

    private void backJBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backJBtnActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);

    }//GEN-LAST:event_backJBtnActionPerformed

    private void suppJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_suppJComboBoxActionPerformed
        // TODO add your handling code here:

        if (suppJComboBox.getSelectedItem() == null || categoryJComboBox.getSelectedItem() == null) {
            System.out.println("Supp= " + suppJComboBox.getSelectedItem() + " cat= " + categoryJComboBox.getSelectedItem().equals("All"));
            populateTableProduct();
        } else if (suppJComboBox.getSelectedItem().equals("All") && categoryJComboBox.getSelectedItem().equals("All")) {
            populateTableProduct();
        } else if (!suppJComboBox.getSelectedItem().equals("All") && categoryJComboBox.getSelectedItem().equals("All")) {
            String suppName = (String) suppJComboBox.getSelectedItem();

            populateTableProductSupplier(suppName);

        } else if (suppJComboBox.getSelectedItem().equals("All") && !categoryJComboBox.getSelectedItem().equals("All")) {

            String category = (String) categoryJComboBox.getSelectedItem();

            populateTableProductCategory(category);

        } else {
            String suppName = (String) suppJComboBox.getSelectedItem();
            String category = (String) categoryJComboBox.getSelectedItem();

            populateTableProduct(suppName, category);
        }


    }//GEN-LAST:event_suppJComboBoxActionPerformed

    private void categoryJComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoryJComboBoxActionPerformed
        // TODO add your handling code here:
        if (suppJComboBox.getSelectedItem() == null || categoryJComboBox.getSelectedItem() == null) {
            System.out.println("Supp= " + suppJComboBox.getSelectedItem() + " cat= " + categoryJComboBox.getSelectedItem().equals("All"));
            populateTableProduct();
        } else if (suppJComboBox.getSelectedItem().equals("All") && categoryJComboBox.getSelectedItem().equals("All")) {
            populateTableProduct();
        } else if (!suppJComboBox.getSelectedItem().equals("All") && categoryJComboBox.getSelectedItem().equals("All")) {
            String suppName = (String) suppJComboBox.getSelectedItem();

            populateTableProductSupplier(suppName);

        } else if (suppJComboBox.getSelectedItem().equals("All") && !categoryJComboBox.getSelectedItem().equals("All")) {

            String category = (String) categoryJComboBox.getSelectedItem();

            populateTableProductCategory(category);

        } else {
            String suppName = (String) suppJComboBox.getSelectedItem();
            String category = (String) categoryJComboBox.getSelectedItem();

            populateTableProduct(suppName, category);
        }
    }//GEN-LAST:event_categoryJComboBoxActionPerformed

    public void populateTableProduct(String suppName, String category) {

        int rowCount = prodJTbl.getRowCount();

        DefaultTableModel model = (DefaultTableModel) prodJTbl.getModel();

        for (int i = rowCount - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(prodJTbl.getModel());
        prodJTbl.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        sortKeys.add(new RowSorter.SortKey(4, SortOrder.DESCENDING));
        sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));

        sorter.setSortKeys(sortKeys);
        int noOfProd = 0;
        double salesPrice = 0;

        for (Product p : business.getProductDirectory().getProductDirectory()) {
            if (p.getCategories().equalsIgnoreCase(category) && business.getSupplierName(p).getSupplier_name().equalsIgnoreCase(suppName)) {
                for (Customer cust : business.getCustomerDirectory().getCustomerDirectory()) {
                    for (OrderItem oi : cust.getOrderList()) {
                        if (oi.getProduct().equals(p)) {
                            if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {
                                noOfProd = noOfProd + oi.getQuantity();
                                salesPrice = salesPrice + oi.getSalesPrice();
                            }
                        }
                    }
                }
                Object Row[] = new Object[5];
                Row[0] = p.getProdName();
                Row[1] = p.getCategories();
                Row[2] = business.getSupplierName(p);
                Row[3] = noOfProd;
                Row[4] = salesPrice;

                model.addRow(Row);

                noOfProd = 0;
                salesPrice = 0;

            }
        }

    }

    public void populateTableProductSupplier(String suppName) {

        int rowCount = prodJTbl.getRowCount();

        DefaultTableModel model = (DefaultTableModel) prodJTbl.getModel();

        for (int i = rowCount - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(prodJTbl.getModel());
        prodJTbl.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        sortKeys.add(new RowSorter.SortKey(4, SortOrder.DESCENDING));
        sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));

        sorter.setSortKeys(sortKeys);
        int noOfProd = 0;
        double salesPrice = 0;

        for (Product p : business.getProductDirectory().getProductDirectory()) {
            if (business.getSupplierName(p).getSupplier_name().equalsIgnoreCase(suppName)) {
                for (Customer cust : business.getCustomerDirectory().getCustomerDirectory()) {
                    for (OrderItem oi : cust.getOrderList()) {
                        if (oi.getProduct().equals(p)) {
                            if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {
                                noOfProd = noOfProd + oi.getQuantity();
                                salesPrice = salesPrice + oi.getSalesPrice();
                            }
                        }
                    }
                }
                Object Row[] = new Object[5];
                Row[0] = p.getProdName();
                Row[1] = p.getCategories();
                Row[2] = business.getSupplierName(p);
                Row[3] = noOfProd;
                Row[4] = salesPrice;

                model.addRow(Row);

                noOfProd = 0;
                salesPrice = 0;

            }
        }

    }

    public void populateTableProductCategory(String category) {

        int rowCount = prodJTbl.getRowCount();

        DefaultTableModel model = (DefaultTableModel) prodJTbl.getModel();

        for (int i = rowCount - 1; i >= 0; i--) {
            model.removeRow(i);
        }

        TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(prodJTbl.getModel());
        prodJTbl.setRowSorter(sorter);

        List<RowSorter.SortKey> sortKeys = new ArrayList<>();

        sortKeys.add(new RowSorter.SortKey(4, SortOrder.DESCENDING));
        sortKeys.add(new RowSorter.SortKey(3, SortOrder.DESCENDING));

        sorter.setSortKeys(sortKeys);
        int noOfProd = 0;
        double salesPrice = 0;

        for (Product p : business.getProductDirectory().getProductDirectory()) {
            if (p.getCategories().equalsIgnoreCase(category)) {
                for (Customer cust : business.getCustomerDirectory().getCustomerDirectory()) {
                    for (OrderItem oi : cust.getOrderList()) {
                        if (oi.getProduct().equals(p)) {
                            if (!oi.getOrderStatus().equalsIgnoreCase("cancelled")) {
                                noOfProd = noOfProd + oi.getQuantity();
                                salesPrice = salesPrice + oi.getSalesPrice();
                            }
                        }
                    }
                }
                Object Row[] = new Object[5];
                Row[0] = p.getProdName();
                Row[1] = p.getCategories();
                Row[2] = business.getSupplierName(p);
                Row[3] = noOfProd;
                Row[4] = salesPrice;

                model.addRow(Row);

                noOfProd = 0;
                salesPrice = 0;

            }
        }

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backJBtn;
    private javax.swing.JComboBox<String> categoryJComboBox;
    private javax.swing.JTable custDataJTbl;
    private javax.swing.JButton getRevenueJBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable prodJTbl;
    private javax.swing.JTextField revenueBetTxtField;
    private javax.swing.JTable suppDataJTbl;
    private javax.swing.JComboBox<String> suppJComboBox;
    private javax.swing.JTextField totalAdminRevenueJTxtField;
    // End of variables declaration//GEN-END:variables
}
